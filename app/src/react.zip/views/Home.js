import React, {Component} from "react";
import Card from "../layouts/Card.js";
import axios from "axios";
class Home extends Component {
    state={
        users: []
    }
    componentDidMount(){
        axios.get('http://localhost:5000/user/list')
        .then(response => {
            console.log(response.data.data)
        })
    }
    render() {
        const users = this.state.users;
        return (
            <div className="container">
                <div className="row row-cols-1 row-cols-sm-2 row-cols-md-4">
                    {
                        users.map(user => {
                            return <Card key={user.user_id} name={user.name} mietTa={user.phong_ban} image={user.image} ></Card>;
                        })
                    }
                    <a href="/form" className="btn btn-primary">Thêm</a>
                </div>
            </div>
        );
    }
}
export default Home;